-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mar 09 Juin 2020 à 04:46
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `site-e-commerce`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomCat` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nomCat`) VALUES
(20, 'Ordinateur Portable'),
(21, 'Ordinateur Bureau'),
(22, 'Peripherique');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenoms` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenoms`, `email`, `password`, `adresse`, `tel`) VALUES
(1, 'Nikiema', 'Boubacar', 'nikiema@gmail.com', 'Nikiema00225', 'Cite international', '0605040708'),
(2, 'Diaw', 'Malick', 'malick@gmail.com', 'Nikiema', 'Hay nada 1', '0676861686'),
(3, 'Camara', 'Mohamed', 'mohamed@gmail.com', 'camara00225', 'Cite internationale de Rabat', '0502412314'),
(4, 'Camara', 'Abdoul Kader', 'kader@gmail.com', '$2y$10$ygN7crMTFXUDANK9giELw.ik3mYM5yGAennUEMYdjhoLc3mug7xpe', 'hay Riad', '06050401235'),
(9, 'hamza', 'Abdellah', 'hamza@gmail.com', '1213', 'hamza@gmail.com', '0605040708');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produit` varchar(255) NOT NULL,
  `quantite` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `commande`
--

INSERT INTO `commande` (`id`, `produit`, `quantite`, `transaction_id`) VALUES
(1, 'Mac book', 2, 1),
(2, 'Mac book', 2, 1),
(3, 'Sucre', 1, 2),
(4, 'Sucre', 1, 2),
(5, 'Sucre', 1, 2),
(6, 'Sucre', 1, 2),
(7, 'Sucre', 1, 2),
(8, 'Sucre', 1, 2),
(9, 'Asus', 1, 2),
(10, ' Ecran HP EliteDisplay ', 1, 2),
(11, 'APC SURGEARREST 1 PRISE ', 1, 2),
(12, ' Ecran HP EliteDisplay ', 1, 2),
(13, 'APC SURGEARREST 1 PRISE ', 1, 2),
(14, ' Ecran HP EliteDisplay ', 1, 1),
(15, 'APC SURGEARREST 1 PRISE ', 2, 3),
(16, 'APC SURGEARREST 1 PRISE ', 1, 1),
(17, 'HP 250 G7 ', 5, 4),
(18, 'APC SURGEARREST 1 PRISE ', 1, 5),
(19, 'APC SURGEARREST 1 PRISE ', 2, 6),
(20, 'ASUS X540UA ', 1, 6),
(21, 'ASUS X540UA ', 3, 7),
(22, 'Asus', 1, 8);

-- --------------------------------------------------------

--
-- Structure de la table `poids`
--

CREATE TABLE IF NOT EXISTS `poids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prix` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `poids`
--

INSERT INTO `poids` (`id`, `nom`, `prix`) VALUES
(1, '200', 10),
(2, '500', 15),
(3, '1000', 20),
(4, '2000', 25),
(5, '3000', 30),
(6, '5000', 35),
(7, '10000', 37),
(8, '50000', 40),
(9, '100000', 50);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE IF NOT EXISTS `produit` (
  `Reference` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `categorie` varchar(255) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `prix` float NOT NULL,
  `poids` varchar(255) NOT NULL,
  `shipping` int(11) NOT NULL,
  `tva` float NOT NULL,
  `prix_final` float NOT NULL,
  `stock` int(11) NOT NULL,
  PRIMARY KEY (`Reference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`Reference`, `titre`, `categorie`, `description`, `prix`, `poids`, `shipping`, `tva`, `prix_final`, `stock`) VALUES
(22, 'Asus', 'Ordinateur Portable', 'ASUS X540MA-GO038. Type de produit: Ordinateur portable, Elément de format: Clapet. Famille de processeur: Intel® Celeron®, Modèle de processeur: N4000, Fréquence du processeur: 1,10 GHz. Taille de l''écran: 39,6 cm (15.6"), Type HD: HD, Résolution de l''écran: 1366 x 768 pixels. Mémoire interne: 4 Go, Type de mémoire interne: LPDDR4-SDRAM. Capacité totale de stockage: 500 Go, Supports de stockage: Disque dur. À bord adaptateur graphique. Système d''exploitation installé: FreeDos', 2500, '3000', 30, 2, 2810.5, 4),
(23, 'ASUS X441MA-GA0011', 'Ordinateur Portable', 'ASUS X441MA-GA0011. Type de produit: Ordinateur portable, Elément de format: Clapet. Famille de processeur: Intel® Celeron®, Modèle de processeur: N4000, Fréquence du processeur: 1,10 GHz. Taille de l''écran: 35,6 cm (14"), Type HD: HD, Résolution de l''écran: 1366 x 768 pixels. Mémoire interne: 4 Go. Capacité totale de stockage: 500 Go, Supports de stockage: Disque dur. Type de lecteur optique: DVD Super Multi. À bord adaptateur graphique. Système d''exploitation installé: FreeDos', 4571, '5000', 35, 2, 62.7, 4),
(24, 'HP 250 G7 ', 'Ordinateur Portable', '       Pack: PC Portable HP 250 G7 /Intel Core /i3-7020U /2,3 GHz /4 Go /500 Go /15.6&quot; /Intel® HD 620 /FreeDos + Imprimante HP DeskJet 2130 Gratuite', 7500, '10000', 37, 2, 7560, 3),
(25, 'ASUS X540UA ', 'Ordinateur Portable', '     Pack: PC Portable ASUS X540UA Touch /i3-7020U /4 Go /1 To /Noir /15&quot; /HD /Windows 10 + Imprimante Canon PIXIMA MG2540S Gratuite', 8500, '10000', 37, 2, 8555, 4),
(26, '  Acer Aspire ', 'Ordinateur Bureau', '   Acer Aspire AXC-703, PFC220W, 2 GHz, Intel® Pentium® Processor Quad core J2900, 2 Go, 500Go, DVD+RW, FreeDos\r\n\r\n', 1500, '2000', 25, 2, 1545, 3),
(27, ' Ecran HP EliteDisplay ', 'Ordinateur Bureau', '   Ecran HP EliteDisplay E202 ( 20 pouces): 1 port VGA; 1 port HDMI, 1 DisplayPort 1,2\r\n\r\n', 1800, '2000', 25, 2, 1845, 1),
(28, 'HP ELITEDISPLAY E223', 'Ordinateur Bureau', '   HP EliteDisplay E223 21,5-pouces: 1DP, HDMI, VGA, 3 USB 3.0  GARANTIE 3 ANS\r\n\r\n', 2500, '3000', 30, 2, 2555, 11),
(30, 'APC SURGEARREST 1 PRISE ', 'Peripherique', '   APC SURGEARREST 1 PRISE - 230V (PM1W-FR)', 100, '200', 10, 2, 110, 2),
(31, 'APC SURGEARREST 5 PRISES', 'Peripherique', '   APC SURGEARREST 5 PRISES - 230V (PM5-FR)\r\n', 155, '200', 10, 2, 165, 4),
(32, 'APC POWER PACK', 'Peripherique', '   APC Onduleur Power Pack 3000 mAh, tension de sortie 5V, 1 x 5V/1A\r\n\r\n', 280, '500', 15, 2, 300, 14),
(33, 'APC SURGEARREST 8 PRISES', 'Peripherique', '   \r\nAPC SurgeArrest 8 Prises - 230V (PM8-FR)\r\nAPC SurgeArrest 8 Prises - 230V (PM8-FR)\r\nPROMO !\r\n-220,00 MAD\r\nAPC SURGEARREST 8 PRISES - 230V (PM8-FR)', 310, '500', 15, 2, 330, 4);

-- --------------------------------------------------------

--
-- Structure de la table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenoms` varchar(255) NOT NULL,
  `pays` varchar(255) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `prixTotal` float NOT NULL,
  `shipping` float NOT NULL,
  `currency_code` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `userID` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `transaction`
--

INSERT INTO `transaction` (`id`, `nom`, `prenoms`, `pays`, `ville`, `adresse`, `date`, `prixTotal`, `shipping`, `currency_code`, `transaction_id`, `userID`) VALUES
(1, 'Diaw', 'Malick', 'Maroc', 'Rabat', 'Haynada', '2020-06-08 06:23:36', 154, 20, 'Eur', '1', 1),
(2, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(3, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(4, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(5, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(6, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(7, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(8, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(9, 'Diaw', 'Malick', 'MAROC', 'RABAT', 'Hay nada 1', '2008-06-20 10:06:00', 23.2, 10, 'DHS', '2', 2),
(10, 'Nikiema', 'Boubacar', 'MAROC', 'RABAT', 'Cite international', '2009-06-20 03:06:00', 4525, 37, 'DHS', '2', 1),
(11, 'Nikiema', 'Boubacar', 'MAROC', 'RABAT', 'Cite international', '2009-06-20 03:06:00', 1968, 30, 'DHS', '3', 1),
(12, 'Nikiema', 'Boubacar', 'MAROC', 'RABAT', 'Cite international', '2009-06-20 03:06:00', 2070, 30, 'DHS', '1', 1),
(13, 'Nikiema', 'Boubacar', 'MAROC', 'RABAT', 'Cite international', '2009-06-20 04:06:00', 112, 10, 'DHS', '1', 1),
(14, 'Camara', 'Mohamed', 'MAROC', 'RABAT', 'Cite internationale ', '2009-06-20 04:06:00', 38290, 40, 'DHS', '4', 3),
(15, 'Camara', 'Mohamed', 'MAROC', 'RABAT', 'Cite internationale ', '2020-06-09 04:06:41', 112, 10, 'DHS', '5', 3),
(16, 'Camara', 'Mohamed', 'MAROC', 'RABAT', 'Cite internationale de Rabat', '2020-06-09 04:06:37', 8914, 40, 'DHS', '6', 3),
(17, 'Nikiema', 'Boubacar', 'MAROC', 'RABAT', 'Cite international', '2020-06-09 04:06:37', 26050, 40, 'DHS', '7', 1),
(18, 'hamza', 'Abdellah', 'MAROC', 'RABAT', 'hamza@gmail.com', '2020-06-09 04:06:00', 2580, 30, 'DHS', '8', 9);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
